# Cloudify Hello World Example

This repository contains a Hello World example blueprint based on OpenStack.

This example creates a VM on OpenStack and starts an HTTP server using a bash script.

If you're only now starting to work with Cloudify see our [Getting Started Guide](http://getcloudify.org/guide/quickstart.html).
