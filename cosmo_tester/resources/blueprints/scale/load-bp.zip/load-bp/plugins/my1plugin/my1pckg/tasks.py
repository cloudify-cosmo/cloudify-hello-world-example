########
# Copyright (c) 2014 GigaSpaces Technologies Ltd. All rights reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
#    * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    * See the License for the specific language governing permissions and
#    * limitations under the License.



from cloudify.decorators import workflow
from cloudify.workflows import ctx

import requests
import time
import uuid
import subprocess
import math


@workflow
def my1geturl(url, cycle_num, cycle_sleep, **kwargs):
    ctx.logger.info("*** my1plugin::my1geturl")
    ctx.logger.info("*** url: {0} *** cycle_num: {1} *** cycle_sleep: {2}".format(url, cycle_num, cycle_sleep))
    for i in range(cycle_num):
        r=requests.get(url)
        time.sleep(cycle_sleep/1000.0)


@workflow
def my1gentar(cycle_num, cycle_sleep, **kwargs):
    ctx.logger.info("*** my1plugin::my1gentar")
    ctx.logger.info("*** cycle_num: {0} *** cycle_sleep: {1}".format(cycle_num, cycle_sleep))
    for i in range(cycle_num):
        unique_filename = '/tmp/' + str(uuid.uuid4()) + '.tgz'
        subprocess.call(['sudo', 'tar', '-czf', unique_filename, '/opt/manager/'])
        subprocess.call(['sudo', 'rm', '-f', unique_filename])
        time.sleep(cycle_sleep/1000.0)


@workflow
def my1factorial(factto, cycle_num, cycle_sleep, **kwargs):
    ctx.logger.info("*** my1plugin::my1factorial")
    ctx.logger.info("*** factto: {0} *** cycle_num: {1} *** cycle_sleep: {2}".format(factto, cycle_num, cycle_sleep))
    for i in range(cycle_num):
        math.factorial(factto)
        time.sleep(cycle_sleep/1000.0)


