default["create_file"]["file_name"] = "/tmp/chef-works"
default["create_file"]["file_contents"] = "yes!\n"
