/**
 * this is an example file for configuration. we chose js to support comments
 *
 * your file should be named me.json and not include 'var conf' at the beginning and ';' at the end or any comments
 **/


var conf = {
    'db': {'mongo':'mongodb://127.0.0.1:27017/composer','nedb':'nedb-data'},
    'sessionSecret': 'blueprint-composer-secret', // some random string to be used when encrypting cookies
    'dslParser': { // optional. if does not exist, will use mock implementation.
        'virtualenv': 'absolute-path-to-virtualenv-basedir', // location to virtualenv with dsl-parser-cli command available
        'cliUrl': 'absolute-path-or-url-to-dsl-cli-sources' // location of source to use with pip install for dsl-parser-cli. relevant for list-operations
    }
};


